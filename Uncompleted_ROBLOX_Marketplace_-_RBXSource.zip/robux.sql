-- phpMyAdmin SQL Dump
-- version 4.5.3.1
-- http://www.phpmyadmin.net
--
-- Host: dbhandle.robux.exchange
-- Generation Time: Apr 08, 2016 at 02:04 PM
-- Server version: 5.6.25-log
-- PHP Version: 7.0.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `robux`
--

-- --------------------------------------------------------

--
-- Table structure for table `Config`
--

CREATE TABLE `Config` (
  `PayPal` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Config`
--

INSERT INTO `Config` (`PayPal`) VALUES
('nicholas@avatar-nation.com');

-- --------------------------------------------------------

--
-- Table structure for table `Limiteds`
--

CREATE TABLE `Limiteds` (
  `ID` int(11) NOT NULL,
  `ItemID` int(20) NOT NULL,
  `SellerID` int(20) NOT NULL,
  `Cost` int(5) NOT NULL,
  `Status` enum('Available','Processing','Taken') NOT NULL DEFAULT 'Available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

--
-- Table structure for table `LimitedTransactions`
--

CREATE TABLE `LimitedTransactions` (
  `TransactionID` varchar(255) NOT NULL,
  `Item` varchar(255) NOT NULL,
  `LimitedID` int(11) NOT NULL,
  `Seller` varchar(255) NOT NULL,
  `Buyer` varchar(255) NOT NULL,
  `USD` varchar(255) NOT NULL,
  `Payed` enum('Y','N') NOT NULL DEFAULT 'N',
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

--
-- Table structure for table `Shops`
--

CREATE TABLE `Shops` (
  `ID` int(11) NOT NULL,
  `GroupId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Shops`
--

INSERT INTO `Shops` (`ID`, `GroupId`) VALUES
(1, 260996);

-- --------------------------------------------------------

--
-- Table structure for table `Transactions`
--

CREATE TABLE `Transactions` (
  `TransactionID` varchar(255) NOT NULL,
  `USD` int(10) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Shop` varchar(255) NOT NULL,
  `Amount` int(10) NOT NULL,
  `Payed` enum('Y','N') NOT NULL DEFAULT 'N',
  `Claimed` enum('Y','N') NOT NULL DEFAULT 'N',
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Indexes for dumped tables
--

--
-- Indexes for table `Limiteds`
--
ALTER TABLE `Limiteds`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Shops`
--
ALTER TABLE `Shops`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ID` (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Limiteds`
--
ALTER TABLE `Limiteds`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `Shops`
--
ALTER TABLE `Shops`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
