<?php
	include_once 'Header.php';
	
	$ID = $RBXAPI->SecurePost($_GET['id']);
	$gP = mysql_fetch_object($getPackage = mysql_query("SELECT * FROM Transactions WHERE TransactionID='".$ID."'"));
	

	$business = $CF->PayPal;
	$amount = $gP->USD;
	$return = 'http://'.$_SERVER['SERVER_NAME'].'/Processed.php?action=success&Trans='.$gP->TransactionID;
	$notifyurl = 'http://'.$_SERVER['SERVER_NAME'].'/Processed.php?action=ipn';
	$cancelreturn = 'http://'.$_SERVER['SERVER_NAME'].'/Processed.php?action=cancel';
	
  	$paypalurl = "https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&amount=".
  	urlencode($amount)."&business=".urlencode($business)."&item_name=".
	urlencode('R$ '.$gP->Amount)."&item_number=".urlencode($gP->TransactionID)."&return=".
	urlencode($return)."&rm=2&notify_url=".
	urlencode($notifyurl)."&cancel_return=".
	urlencode($cancelreturn)."&no_note=1&currency_code=USD&custom=".
	urlencode($gP->Username);
    
	if ($gP->Claimed == "Y"){
   		echo '
			<body class="body">
  				<div class="w-container container">
    				<div class="main card white col s12">
    					<div class="card-content">
            				This was already claimed.
        				</div>
    				</div>
  				</div>
			</body>
		';
	} else { 
		header( 'Location: '.$paypalurl);
	}
?>