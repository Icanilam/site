<?php
	include_once 'Header.php';
?><head>
    <title>Robux Exchange</title>
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="/css/materialize.min.css" media="screen,projection">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" rel="stylesheet" href="/css/temp.css">
    <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
	<script type="text/javascript" src="/js/materialize.min.js"></script>
</head>

<link type="text/css" rel="stylesheet" href="/css/webflow.css">
<link type="text/css" rel="stylesheet" href="/css/robuxexchange.webflow.css">
<body class="body">
  <div class="w-container container">
    <div class="main card white col s12">
    	<div class="card-content">
        	<h3>Nothing on this page works yet.</h3>
            <h3> Purchase Robux: <a href="http://www.robux.exchange/group-purchase.php?Shop=1">here</a></h3>
            <h3> Purchase Limiteds: <a href="http://www.robux.exchange/limiteds/">here</a></h3>
            <h3>Credit to infamy for the purchase page look.</h3>
            <h2 class="heading">Robux Shops</h2>
            <br>
    		<div class="w-row">
      			<div class="w-col w-col-4"><img src="https://d3e54v103j8qbb.cloudfront.net/img/image-placeholder.svg" class="groupimage">
        			<div class="grouptitle"><strong data-new-link="true">Group Name</strong>
        			</div>
        			<div class="robux label">Robux Stock: <span class="robux rbx" id="grouprobux">25,000</span> <span class="robux rbx">R$</span>
        			</div>
      			</div>
      			<div class="w-col w-col-4"><img src="https://d3e54v103j8qbb.cloudfront.net/img/image-placeholder.svg" class="groupimage">
        			<div class="grouptitle"><strong data-new-link="true">Group Name</strong>
        			</div>
        			<div class="robux label">Robux Stock: <span class="robux rbx" id="grouprobux">25,000</span> <span class="robux rbx">R$</span>
        			</div>
      			</div>
      			<div class="w-col w-col-4"><img src="https://d3e54v103j8qbb.cloudfront.net/img/image-placeholder.svg" class="groupimage">
        			<div class="grouptitle"><strong data-new-link="true">Group Name</strong>
        			</div>
        			<div class="robux label">Robux Stock: <span class="robux rbx" id="grouprobux">25,000</span> <span class="robux rbx">R$</span>
        			</div>
      			</div>
    		</div>
        </div>
     </div>
  </div>
  <div class="hiddendiv common"></div>
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <script type="text/javascript" src="js/webflow.js"></script>
</body>