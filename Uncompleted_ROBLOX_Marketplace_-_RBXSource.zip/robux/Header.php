<?
session_start();
$DatabaseHost   = 'dbhandle.robux.exchange';
$DatabaseUser   = 'nrspark';
$DatabasePass   = 'XHr!u7L!';
$DatabaseName   = 'robux';
$Connection		= mysql_pconnect("$DatabaseHost","$DatabaseUser","$DatabasePass") or die ("Spark | Couldn't connect to server.");
$Database 		= mysql_select_db("$DatabaseName", $Connection) or die("Spark | Couldn't select database.");

$CF = mysql_fetch_object($Config = mysql_query("SELECT * FROM Config"));

include_once "API.php";
$RBXAPI = new MyRBLXClass();
?>