<?php
class MyRBLXClass
{
    protected   $encryption     =   'sha256';
    protected   $dir            =   '7f25c7e2395c5f577842ff923f51f1e008909daef9dd560e71656a6bb4d231d0/';
    public      $user           =   'wowggroblox';
	
    // Functions used by other functions
    protected function file_get_contents_curl($url) 
    {
    	$ch = curl_init();
    	
    	curl_setopt($ch, CURLOPT_HEADER, 0);
    	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //Set curl to return the data instead of printing it to the browser.
    	curl_setopt($ch, CURLOPT_URL, $url);
    	
    	$data = curl_exec($ch);
    	curl_close($ch);
    	
    	return $data;
    }
	protected function file_get_contents_cookie($url) 
    {
		$rs = $this->dir . hash($this->encryption, $this->user);
		
    	$get_page_data = curl_init($url);
		curl_setopt_array($get_page_data,
			array(
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_HTTPHEADER => array("Cookie: $rs")
			)
		);
		return $get_page_data;
    }
    protected function get_redirect_url($url)
    { 
    	$redirect_url = null;
    
    	$url_parts = @parse_url($url);
    	if (!$url_parts) return false;
    	if (!isset($url_parts['host'])) return false; //can't process relative URLs
    	if (!isset($url_parts['path'])) $url_parts['path'] = '/';
    	$sock = fsockopen($url_parts['host'], (isset($url_parts['port']) ? (int)$url_parts['port'] : 80), $errno, $errstr, 30);
    	if (!$sock) return false;
    
    	$request = "HEAD " . $url_parts['path'] . (isset($url_parts['query']) ? '?'.$url_parts['query'] : '') . " HTTP/1.1\r\n";
       	$request .= 'Host: ' . $url_parts['host'] . "\r\n";
       	$request .= "Connection: Close\r\n\r\n";
       	fwrite($sock, $request);
       	$response = '';
       	while(!feof($sock)) $response .= fread($sock, 8192);
       	fclose($sock);
    
    	if (preg_match('/^Location: (.+?)$/m', $response, $matches)){
    		if ( substr($matches[1], 0, 1) == "/" )
    			return $url_parts['scheme'] . "://" . $url_parts['host'] . trim($matches[1]);
    		else
            		return trim($matches[1]);
            } else {
    		return false;
    	}
    }
    protected function get_all_redirects($url)
    {
    	$redirects = array();
        	while ($newurl = $this->get_redirect_url($url)){
            	if (in_array($newurl, $redirects))
            	   break;
            	   
                $redirects[] = $newurl;
                $url = $newurl;
        	}
    	return $redirects;
    }
    
    protected function get_final_redirect($url)
    {
    	$redirects = $this->get_all_redirects($url);
    	if (count($redirects)>0)
        	return array_pop($redirects);
        	
    	return $url;
    }
    protected function xpath($url,$path)
    {
        libxml_use_internal_errors(true);
        $dom = new DomDocument;
        $dom->loadHTML($this->file_get_contents_curl($url));
        $xpath = new DomXPath($dom);
        return $xpath->query($path);
    }    
    
    protected function post_with_data($url,$data)
    {
        $ch = curl_init(); 
        curl_setopt ($ch, CURLOPT_URL, $url); 
        curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
        curl_setopt ($ch, CURLOPT_USERAGENT, "Googlebot/2.1"); 
        curl_setopt ($ch, CURLOPT_TIMEOUT, 60); 
        curl_setopt ($ch, CURLOPT_FOLLOWLOCATION, 0); 
        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1); 
        curl_setopt ($ch, CURLOPT_COOKIEJAR, $this->do_hash($this->user)); 
        curl_setopt ($ch, CURLOPT_COOKIEFILE, $this->do_hash($this->user)); 
        curl_setopt ($ch, CURLOPT_REFERER, $url); 
        
        curl_setopt ($ch, CURLOPT_POSTFIELDS, $data); 
        curl_setopt ($ch, CURLOPT_POST, 1);
        
        return curl_exec ($ch);
    }
    
    protected function request_with_cookie($url)
    {
        $ch = curl_init(); 
        curl_setopt ($ch, CURLOPT_URL, $url); 
        curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
        curl_setopt ($ch, CURLOPT_USERAGENT, "Googlebot/2.1"); 
        curl_setopt ($ch, CURLOPT_TIMEOUT, 60); 
        curl_setopt ($ch, CURLOPT_FOLLOWLOCATION, 0); 
        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1); 
        curl_setopt ($ch, CURLOPT_COOKIEJAR, $this->do_hash($this->user)); 
        curl_setopt ($ch, CURLOPT_COOKIEFILE, $this->do_hash($this->user)); 
        curl_setopt ($ch, CURLOPT_REFERER, $url); 
        
        return curl_exec ($ch);        
    }
    
    protected function remove_cookie()
    {
        unlink($this->do_hash($this->user));   
    }
    
    protected function do_hash($var)
    {
        return $this->dir . '/' .  hash($this->encryption, $var);
    }
    
    protected function get_verification_token($url,$bool=true)
    {
        $c = ($bool == false ? $url : $this->request_with_cookie($url));
        $preg = preg_match('/<input name="__RequestVerificationToken" type="hidden" value="(.*?)"/', $c , $matches);
        if(!$preg)
            return false;
            
        return $matches[1];
    }
    
    protected function get_defined_token($page,$token)
    {
        $preg = preg_match('/<input type="hidden" name="'.$token.'" id="'.$token.'" value="(.*?)"/', $page, $matches);
        if(!$preg)
            return false;
            
        return $matches[1];
    }
    
    protected function get_x_csrf_token($url)
    {
        $preg = preg_match("/setToken\('(.*?)'\)/", $this->request_with_cookie($url), $matches);
        if(!$preg)
            return false;
            
        return $matches[1];
    }
    
    protected function request_with_csrf($url,$tokenurl,$data='')
    {
        $token = $this->get_x_csrf_token($tokenurl);
        $ch = curl_init(); 
        curl_setopt ($ch, CURLOPT_URL, $url);
        curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
        curl_setopt ($ch, CURLOPT_USERAGENT, "Googlebot/2.1"); 
        curl_setopt ($ch, CURLOPT_TIMEOUT, 60); 
        curl_setopt ($ch, CURLOPT_FOLLOWLOCATION, 0); 
        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
        
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Connection: keep-alive',
            'X-CSRF-TOKEN: ' . $token,
            'X-Requested-With: XMLHttpRequest',
        ));
        
        curl_setopt ($ch, CURLOPT_COOKIEJAR, $this->do_hash($this->user)); 
        curl_setopt ($ch, CURLOPT_COOKIEFILE, $this->do_hash($this->user));
        curl_setopt ($ch, CURLOPT_REFERER, $url); 
        
        curl_setopt ($ch, CURLOPT_POST, 1);
        curl_setopt ($ch, CURLOPT_POSTFIELDS, $data); 
        
        return curl_exec ($ch);
    }
    
    protected function get_country($country)
    {
        $list   =   array   (
                                'United States'         =>  1,
                                'Germany'               =>  2,
                                'Netherlands'           =>  3,
                                'France'                =>  4,
                                'Spain'                 =>  5,
                                'Italy'                 =>  6,
                                'Ireland'               =>  7,
                                'Portugal'              =>  8,
                                'Canada'                =>  9,
                                'United Kingdom'        =>  10,
                                'Australia'             =>  11,
                                'New Zealand'           =>  12,
                                'Brazil'                =>  13,
                                'Philippines'           =>  14,
                                'Denmark'               =>  15,
                                'Sweden'                =>  16,
                                'United Arab Emirates'  =>  17,
                                'Poland'                =>  18,
                                'Malaysia'              =>  19,
                                'Turkey'                =>  20,
                                'Norway'                =>  21,
                                'Romania'               =>  22,
                                'Thailand'              =>  23,
                                'Singapore'             =>  24,
                                'Mexico'                =>  25,
                                'Saudi Arabia'          =>  26,
                                'Belgium'               =>  27,
                                'Lithuania'             =>  28,
                                'Israel'                =>  29,
                                'Indonesia'             =>  30,
                                'Russia'                =>  31,
                                'Finland'               =>  32,
                            );
                            
        if(array_key_exists($country,$list))
            return $list[$country];
                            
        return 1;
    }
    
    protected function get_gender($gender)
    {
        $list   =   array   (
                                'Male'      =>  2,
                                'Female'    =>  3,
                            );
        if(array_key_exists($gender,$list))
            return $list[$gender];
                            
        return 2; 
    }
    
    protected function get_language($language)
    {
        $list   =   array   (
                                'English'    =>  1,
                                'German'     =>  3,
                            );
        if(array_key_exists($language,$list))
            return $list[$language];
                            
        return 1;         
    }
    
    protected function get_privacy_setting($type,$id)
    {
        $list   =   array   (
                                'SocialNetworksVisibilityPrivacy'   =>  array   (
                                                                                    'AllUsers',
                                                                                    'FriendsFollowingAndFollowers',
                                                                                    'FriendsAndFollowing',
                                                                                    'Friends',
                                                                                    'NoOne',
                                                                                ),
                                                    
                                'ChatVisibilityPrivacy'             =>  array   (
                                                                                    'All',
                                                                                    'Followers',
                                                                                    'Following',
                                                                                    'Friends',
                                                                                    'Noone',
                                                                                    'Disabled'
                                                                                ),
                                                    
                                'PrivateMessagePrivacy'             =>  array   (
                                                                                    'All',
                                                                                    'Followers',
                                                                                    'Following',
                                                                                    'Friends',
                                                                                    'NoOne'
                                                                                ),
                                                    
                                'PartyInvitePrivacy'                =>  array   (
                                                                                    'All',
                                                                                    'Followers',
                                                                                    'Following',
                                                                                    'Friends',
                                                                                    'Noone',
                                                                                    'Disabled'
                                                                                ), 
                                                    
                                'PrivateServerInvitePrivacy'        =>  array   (
                                                                                    'AllAuthenticatedUsers',
                                                                                    'FriendsFollowingAndFollowers',
                                                                                    'FriendsAndFollowing',
                                                                                    'Friends',
                                                                                    'NoOne'
                                                                                ), 
                                                    
                                'FollowMePrivacy'                   =>  array   (
                                                                                    'All',
                                                                                    'Followers',
                                                                                    'Following',
                                                                                    'Friends',
                                                                                    'Noone'
                                                                                ),
                            );
                            
 
            if(array_key_exists($id,$list[$type]))
                return $list[$type][$id];
    }
    
    protected function get_genre_setting($type)
    {
        $list   =   array   (
                                'All'           =>  1,
                                'Building'      =>  19,
                                'Horror'        =>  11,
                                'Town and City' =>  7, 
                                'Military'      =>  17,
                                'Comedy'        =>  15,
                                'Medieval'      =>  8,
                                'Adventure'     =>  13,
                                'Sci-Fi'        =>  9,
                                'Naval'         =>  12,
                                'FPS'           =>  20,
                                'RPG'           =>  21,
                                'Sports'        =>  14,
                                'Fighting'      =>  10,
                                'Western'       =>  16,
                            );
                            
 
            if(array_key_exists($type,$list))
                return $list[$type];
                
            return 1;
    }
    /*
    
        Public functions, no priviliges needed in order to work
    
    */
    
	
	//  Output: hash
	public function UserHash()
	{
		return hash($this->encryption, $this->user);
	}
    //  Output: bool/string
    public function GetUserID($data)
    {
        $p = json_decode($this->file_get_contents_curl(( is_string($data) ? 'http://api.roblox.com/users/get-by-username?username=' : 'http://api.roblox.com/users/').$data), true);
        return ((is_array($p) and array_key_exists('Id', $p)) ? $p['Id'] : '-1');
        
    }
	
	public function RealUser($id)
    {
        return json_decode($this->file_get_contents_curl('http://api.roblox.com/users/get-by-username?username='.$id), true)['errorMessage'];
    }
   
   //  Output: array
    public function GetGroupFunds($id)
    {

        $elements = array   (
            'robux'  =>  "(//div[contains(@id,'ctl00_cphRoblox_rbxGroupFundsPane_GroupFunds')]//span[contains(@class,'robux')])[1]",

        );
        $robux = 0;

        foreach($elements as $name => $element)
        {
            foreach ($this->xpath('http://www.roblox.com/Groups/group.aspx?gid='.$id,$element) as $i => $node)
                $robux    =   $node->textContent;
        }
		return $robux;
    }
   
    //  Output: string
    public function GetUserBlurb($id)
    {
    	foreach ($this->xpath('http://www.roblox.com/users/' . $id . '/profile',"//span[@class='profile-about-content-text']") as $i => $node)
    		return $node->nodeValue;
    }
    
    //  Output: string
    public function GetUserName($id)
    {
        $p = json_decode($this->file_get_contents_curl('http://api.roblox.com/users/'.$id), true);
        return ((is_array($p) and array_key_exists('Username', $p)) ? $p['Username'] : '-1');
    }
	
    //  Output: array
    public function GetUserStats($id)
    {
    	
        $elements = array   (
                                'Friends'       =>  "//span[@id='ctl00_cphRoblox_rbxUserStatisticsPane_lFriendsStatistics']",
                                'Knockouts'     =>  "//span[@id='ctl00_cphRoblox_rbxUserStatisticsPane_lKillsStatistics']",
                                'Followers'     =>  "//span[@id='ctl00_cphRoblox_rbxUserStatisticsPane_lFollowersStatistics']",
                                'Place Visits'  =>  "//span[@id='ctl00_cphRoblox_rbxUserStatisticsPane_lPlaceVisitsStatistics']",
                                'Forum Posts'   =>  "//span[@id='ctl00_cphRoblox_rbxUserStatisticsPane_lForumPostsStatistics']",
                            );
        $data = array();
        
        foreach($elements as $name => $element)
        {
            foreach ($this->xpath('http://www.roblox.com/User.aspx?ID='.$id,$element) as $i => $node)
                $data[$name]    =   $node->nodeValue;
        }
       
       return $data;
    }
    
    // Output: array
    public function GetUserStatus($id)
    {
    	foreach ($this->xpath('http://www.roblox.com/users/' . $id . '/profile',"//span[@id='ctl00_cphRoblox_rbxUserPane_lUserOnlineStatus']") as $i => $node)
    		return array('Status' => $node->nodeValue);
    
    	foreach ($this->xpath('http://www.roblox.com/users/' . $id . '/profile',"//a[@id='ctl00_cphRoblox_rbxUserPane_UserOnlineStatusHyperLink']") as $i => $node)
    	    return array('Status' => $node->nodeValue, 'URL' => 'http://roblox.com' . $node->getAttribute('href'));
     
    }
    
    // Output: array
    public function GetGroupOwner($id)
    {
        return json_decode($this->file_get_contents_curl('http://api.roblox.com/groups/'.$id), true)['Owner']['Id'];
    }   
    
    // Output: string
    public function GetGroupName($id)
    {
        return json_decode($this->file_get_contents_curl('http://api.roblox.com/groups/'.$id), true)['Name'];
    }
    
    // Output: string
    public function GetGroupMembers($id)
    {
        foreach ($this->xpath('http://www.roblox.com/Groups/group.aspx?gid='.$id,"//div[@id='MemberCount']") as $i => $node)  	
        	return str_replace("Members: ", '', $node->nodeValue);
    }
    
    // Output: string
    public function GetGroupdescription($id)
    {
        return json_decode($this->file_get_contents_curl('http://api.roblox.com/groups/'.$id), true)['Description'];  
    }
    
    // Output: string/url
    public function GetGroupImg($id)
    {
        return json_decode($this->file_get_contents_curl('http://api.roblox.com/groups/'.$id), true)['EmblemUrl'];   
    }
    
    // Output: array
    public function GetGroupAllies($id)
    {
        return json_decode($this->file_get_contents_curl('http://api.roblox.com/groups/' . $id . '/allies'),true);    
    }
    
    // Output: array
    public function GetGroupEnemies($id)
    {
        return json_decode($this->file_get_contents_curl('http://api.roblox.com/groups/' . $id . '/enemies'),true);    
    }
    
    // Output: array
    public function GetGroupRoles($id)
    {
        return $this->file_get_contents_curl('http://www.roblox.com/api/groups/'.$id.'/RoleSets/');    
    }
    
    /*
    
        Functions for logged in users, priviliges may apply.
    
    */
    
    public function DoLogin()
    {
		$password = file_get_contents('Secure/password.txt');
        $this->post_with_data('https://m.roblox.com/Login','UserName=' . $this->user . '&Password=' . $password);
    }
    
    public function IsLoggedIn()
    {
        if($this->request_with_cookie('http://www.roblox.com/Game/GetCurrentUser.ashx')!=='null')
            return true;
        
        $this->clear();  
        return false;
    }
    
    public function GetUserFunds()
    {
        return $this->request_with_cookie('http://api.roblox.com/my/balance');
    }
    
    
    public function ModifyAccount($bm,$bd,$by,$gender,$language,$country,$blurb,$newsletter,$yt,$twitch,$sn,$chat,$pm,$party,$vip,$follow)
    {
        $data   =
            '__RequestVerificationToken='.$this->get_verification_token('https://www.roblox.com/my/account').
            '&BirthMonth='.(is_int($bm) ? $bm : 12).
            '&BirthDay='.(is_int($bd) ? $bd : 28).
            '&BirthYear='.(is_int($by) ? $by : 1969).
            '&Gender='.$this->get_gender($gender).
            '&LanguageId='.$this->get_language($language).
            '&CountryId='.$this->get_country($country).
            '&PersonalBlurb='.urlencode($blurb).
            '&ReceiveNewsletter='.($newsletter ? 'true' : 'false').
            '&YouTube='.urlencode($yt).
            '&Twitch='.urlencode($twitch).
            '&SocialNetworksVisibilityPrivacy='.$this->get_privacy_setting('SocialNetworksVisibilityPrivacy',$sn).
            '&ChatVisibilityPrivacy='.$this->get_privacy_setting('ChatVisibilityPrivacy',$chat).
            '&PrivateMessagePrivacy='.$this->get_privacy_setting('PrivateMessagePrivacy',$pm).
            '&PartyInvitePrivacy='.$this->get_privacy_setting('PartyInvitePrivacy',$party).
            '&PrivateServerInvitePrivacy='.$this->get_privacy_setting('PrivateServerInvitePrivacy',$vip).
            '&FollowMePrivacy='.$this->get_privacy_setting('FollowMePrivacy',$follow);
            
        $this->post_with_data('https://www.roblox.com/my/account/update',$data);
    }
    
    public function ChangePassword($old,$new)
    {
        $this->request_with_csrf('https://www.roblox.com/account/changepassword','https://www.roblox.com/my/account','oldPassword='.$old.'&newPassword='.$new.'&confirmNewPassword='.$new);
    }
    
    public function Clear()
    {
        $this->remove_cookie();
    }
    
    public function SetFeeling($status)
    {
        $this->post_with_data('http://m.roblox.com/Account/SetStatus', '__RequestVerificationToken='.$this->get_verification_token('http://m.roblox.com/').'&Status=' .$status);
    }
    
    public function SendPM($to,$subject,$content)
    {
        $this->post_with_data('http://m.roblox.com/messages/sendmessagework', '__RequestVerificationToken='.$this->get_verification_token('http://m.roblox.com/messages/sendmessage?Id='.$to).'&RecipientId=' .$to . '&Subject='.urlencode($subject).'&Body='.urlencode($content));
    }
    public function SetGroupRole($group,$target,$role)
    {
        foreach(json_decode($this->GetGroupRoles($group),true) as $roles){
            if($roles['Name']==$role)
                $this->request_with_csrf('http://www.roblox.com/groups/api/change-member-rank?groupId='.$group.'&newRoleSetId='.$roles['ID'].'&targetUserId='.$target, 'http://www.roblox.com/My/GroupAdmin.aspx?gid='.$group);
        }
    }
    
    public function SendFR($target)
    {
        $this->request_with_csrf('http://www.roblox.com/friends/sendfriendrequest', 'http://www.roblox.com/User.aspx?ID='.$target, 'targetUserId='.$target);
    }
 
    public function FollowUser($target)
    {
        $this->post_with_data('http://www.roblox.com/user/follow','targetUserId='.$target);
    }
    
    public function UnfollowUser($target)
    {
        $this->post_with_data('http://www.roblox.com/user/unfollow','targetUserId='.$target);
    }
    public function BlockUser($target)
    {
        $this->request_with_csrf('http://www.roblox.com/userblock/blockuser','http://www.roblox.com/User.aspx?ID='.$target,'blockeeId='.$target);
    }
    public function UnblockUser($target)
    {
        $this->request_with_csrf('http://www.roblox.com/userblock/unblockuser', 'http://www.roblox.com/User.aspx?ID='.$target,'blockeeId='.$target);
    }
    
    public function IsUserFriended($from,$target)
    {
       return strpos($this->file_get_contents_curl('http://www.roblox.com/Game/LuaWebService/HandleSocialRequest.ashx?method=IsFriendsWith&playerId=' . $from . '&userId=' . $target), 'true') ? true : false;
    }
    
    public function IsUserFollower($from,$target)
    {
        return json_decode($this->request_with_cookie('http://api.roblox.com/user/following-exists?userId='.$from.'&followerUserId='.$target),true)['isFollowing'];
    }
    public function InviteToClan($group,$target)
    {
        $this->post_with_data('http://www.roblox.com/group/invite-to-clan','userIdToInvite='.$target.'&groupId='.$group.'&__RequestVerificationToken='.$this->get_verification_token('http://www.roblox.com/My/GroupAdmin.aspx?gid='.$group));
    }
    
    public function CancelClanInvite($group,$target)
    {
        $this->post_with_data('http://www.roblox.com/group/cancel-invitation','inviteeUserId='.$target.'&groupId='.$group.'&__RequestVerificationToken='.$this->get_verification_token('http://www.roblox.com/My/GroupAdmin.aspx?gid='.$group));
    }
    public function AcceptClanInvite($group,$bool)
    {
        $this->post_with_data('http://www.roblox.com/group/accept-decline-clan-invitation','isAccepting='.$bool.'&groupId='.$group.'&__RequestVerificationToken='.$this->get_verification_token('http://www.roblox.com/My/GroupAdmin.aspx?gid='.$group));
    }
    public function KickFromClan($group,$target)
    {
        $this->post_with_data('http://www.roblox.com/group/kick-from-clan','userIdToKick='.$target.'&groupId='.$group.'&__RequestVerificationToken='.$this->get_verification_token('http://www.roblox.com/My/GroupAdmin.aspx?gid='.$group));
    }
    public function KickFromGroup($group,$target,$bool)
    {
        $this->post_with_data('http://www.roblox.com/My/Groups.aspx/ExileUserAndDeletePost',json_encode(array('userId'=>$target, 'deleteAllPostsOption'=>$bool, 'rolesetId' => '', 'selectedGroupId' => $group)));
    }       
    public function LeaveClan($group)
    {
        $this->post_with_data('http://www.roblox.com/group/leave-clan','groupId='.$group.'&__RequestVerificationToken='.$this->get_verification_token('http://www.roblox.com/My/Groups.aspx?gid='.$group));
    }
	
	public function GiveGroupFunds($group,$userid,$amount)
    {
		$this->request_with_csrf('http://www.roblox.com/groups/'.$group.'/one-time-payout/1/false','http://www.roblox.com/my/groupadmin.aspx?gid='.$group,'percentages='.urlencode(json_encode(array($userid   =>  $amount))));
		
    }
	
	public function SendTrade($buyer,$itemid)
    {
		$BuyerInfo = json_decode(file_get_contents('http://www.robux.exchange/GetLimiteds.php?userId='.$buyer));
		$ItemFromBuyer;
		foreach ($BuyerInfo as $key => $value) {if ($key == "Limiteds") {foreach($value as $data => $val) {
			if ($val->AveragePrice <= 300) {
				$ItemFromBuyer = $val;
			}
		}}}
		
		$SellerInfo = json_decode(file_get_contents('http://www.robux.exchange/GetLimiteds.php?userId='.$this->GetUserID($this->user)));
		$ItemFromSeller;
		foreach ($SellerInfo as $key1 => $value1) {if ($key1 == "Limiteds") {foreach($value1 as $data1 => $val1) {
			$MatchID = preg_match('/\?id=(\d+)$/', $val1->ItemLink, $matches) ? $matches[1] : '';
			if ($MatchID == $itemid) {
				$ItemFromSeller = $val1;
			}
		}}}
		
		
		$this->request_with_csrf('http://www.roblox.com/Trade/tradehandler.ashx','http://www.roblox.com/my/money.aspx#/#TradeItems_tab','cmd=send&TradeJSON='.urlencode('{"AgentOfferList":[{"AgentID":'.$this->GetUserID($this->user).',"OfferList":[{"Name":"'.$ItemFromSeller->Name.'","ImageLink":"'.$ItemFromSeller->ImageLink.'","ItemLink":"'.$ItemFromSeller->ItemLink.'","SerialNumber":"'.$ItemFromSeller->SerialNumber.'","SerialNumberTotal":"'.$ItemFromSeller->SerialNumberTotal.'","AveragePrice":"'.$ItemFromSeller->AveragePrice.'","OriginalPrice":"'.$ItemFromSeller->OriginalPrice.'","UserAssetID":"'.$ItemFromSeller->UserAssetID.'","MembershipLevel":null}],"OfferRobux":0,"OfferValue":'.$ItemFromSeller->AveragePrice.'},{"AgentID":'.$buyer.',"OfferList":[{"Name":"'.$ItemFromBuyer->Name.'","ImageLink":"'.$ItemFromBuyer->ImageLink.'","ItemLink":"'.$ItemFromBuyer->ItemLink.'","SerialNumber":"'.$ItemFromBuyer->SerialNumber.'","SerialNumberTotal":"'.$ItemFromBuyer->SerialNumberTotal.'","AveragePrice":"'.$ItemFromBuyer->AveragePrice.'","OriginalPrice":"'.$ItemFromBuyer->OriginalPrice.'","UserAssetID":"'.$ItemFromBuyer->UserAssetID.'","MembershipLevel":null}],"OfferRobux":0,"OfferValue":'.$ItemFromBuyer->AveragePrice.'}],"IsActive":false,"TradeStatus":"Open"}'));
		
		return;
		
    }
    
    public function BuyAsset($asset,$currency=2) // 2 = tx; 1= r$
    {
        $data = $this->GetAsset($asset);
        if($data['IsPublicDomain'] == false)
        {
            if($currency==2 and $data['PriceInTickets'] !== 'null') { $d = $data['PriceInTickets']; }
            elseif($currency==1 and $data['PriceInRobux'] !== 'null') { $d = $data['PriceInRobux']; }
            else { return; }
        
            $this->request_with_csrf('http://www.roblox.com/API/Item.ashx?rqtype=purchase&productID=' . $data['ProductId'] . '&expectedCurrency=' . $currency . '&expectedPrice=' . $d .'&expectedSellerID=' . $data['Creator']['Id'], 'http://www.roblox.com/item.aspx?--&id=' . $asset);
        }
        else
            $this->request_with_csrf('http://www.roblox.com/API/Item.ashx?rqtype=purchase&productID=' . $data['ProductId'] . '&expectedCurrency=1&expectedPrice=0&expectedSellerID=' . $data['Creator']['Id'], 'http://www.roblox.com/item.aspx?--&id=' . $asset);
                                    
    }
    
    public function GetAsset($asset)
    {
        return json_decode($this->file_get_contents_curl('http://api.roblox.com/Marketplace/ProductInfo?assetId=' . $asset), true);
    }
    
    public function ChangePlaceState($place,$active)
    {
        $this->request_with_csrf('http://www.roblox.com/build/set-place-state?placeId='. $place . '&active=' . $active, 'http://www.roblox.com/develop?close=1');
    }
    
    public function GetUserPlaces($user)
    {
        return json_decode($this->file_get_contents_curl('http://www.roblox.com/Contests/Handlers/Showcases.ashx?userId=' . $user), true);
    }
    
    public function HasAsset($user,$asset)
    {
        return (($this->file_get_contents_curl('http://api.roblox.com/Ownership/HasAsset?userId=' . $user . '&assetId=' . $asset) == 'true') ? true : false);
    }
    
    public function RedeemPromocode($code)
    {
        $this->post_with_data('http://www.roblox.com/promocodes/redeem?code='.$code,'');
    }
    
    public function UpdateAsset($id,$name,$description,$comments,$gengre,$selling,$robux=0,$tx=0)
    {
        $p = $this->request_with_cookie('http://www.roblox.com/My/Item.aspx?ID='.$id);
                                                                                
        if ($robux == 0 and $tx ==0)
            $this->post_with_data('http://www.roblox.com/My/Item.aspx?ID='.$id, 
                                                                                '__EVENTTARGET=ctl00$cphRoblox$SubmitButtonTop'.
                                                                                '&__EVENTARGUMENT='.
                                                                                '&__VIEWSTATE='.urlencode($this->get_defined_token($p, '__VIEWSTATE')).
                                                                                '&__EVENTVALIDATION='.urlencode($this->get_defined_token($p, '__EVENTVALIDATION')).
                                                                                '&ctl00$cphRoblox$NameTextBox='.urlencode($name).
                                                                                '&ctl00$cphRoblox$DescriptionTextBox='.urlencode($description).
                                                                                '&ctl00$cphRoblox$EnableCommentsCheckBox='.(($comments==true) ? 'on' : '').
                                                                                '&GenreButtons2='.$this->get_genre_setting($genre).
                                                                                '&ctl00$cphRoblox$actualGenreSelection='.$this->get_genre_setting($genre).
                                                                                '&ctl00$cphRoblox$PublicDomainCheckBox='.(($selling==true) ? 'on' : '')
                                                                                );        
        
        $this->post_with_data('http://www.roblox.com/My/Item.aspx?ID='.$id,     
                                                                                '__EVENTTARGET=ctl00$cphRoblox$SubmitButtonTop'.
                                                                                '&__EVENTARGUMENT='.
                                                                                '&__VIEWSTATE='.urlencode($this->get_defined_token($p, '__VIEWSTATE')).
                                                                                '&__EVENTVALIDATION='.urlencode($this->get_defined_token($p, '__EVENTVALIDATION')).
                                                                                'ctl00$cphRoblox$NameTextBox='.urlencode($name).
                                                                                '&ctl00$cphRoblox$DescriptionTextBox='.urlencode($description).
                                                                                '&ctl00$cphRoblox$SellThisItemCheckBox='.(($selling==true) ? 'on' : '').
                                                                                '&ctl00$cphRoblox$SellForRobux='.(($robux > 2) ? 'on' : '').
                                                                                '&ctl00$cphRoblox$SellForTickets='.(($tx > 20) ? 'on' : '').
                                                                                '&ctl00$cphRoblox$RobuxPrice='.(($robux > 2) ? $robux : 2).
                                                                                '&ctl00$cphRoblox$TicketsPrice='.(($tx > 20) ? $tx : 20).
                                                                                '&ctl00$cphRoblox$actualGenreSelection='.$this->get_genre_setting($genre).
                                                                                '&GenreButtons2='.$this->get_genre_setting($genre).
                                                                                '&ctl00$cphRoblox$EnableCommentsCheckBox='.(($comments==true) ? 'on' : '')
                                                                                );
            
                
    }
       
    public function ToggleFavoriteAsset($id)
    {
        $this->post_with_data('http://www.roblox.com/favorite/toggle', 'assetId='.$id);
    }
    
    public function Vote($asset, $bool = null)
    {
        $this->post_with_data('http://www.roblox.com/voting/vote?assetId='.$asset.'&vote=' . (strtolower($bool)=='up') ? 'true' : (strtolower($bool)=='down') ? 'false' : 'null' , '');
    }
    
    public function SetGroupShout($group,$content)
    {
        $p = $this->request_with_cookie('http://www.roblox.com/My/Groups.aspx?gid='.$group);
        $this->post_with_data('http://www.roblox.com/My/Groups.aspx?gid='.$group, 
                                                                                '&__RequestVerificationToken='.$this->get_verification_token($p,false).
                                                                                '&__VIEWSTATE='.urlencode($this->get_defined_token($p, ('__VIEWSTATE'))).
                                                                                '&__EVENTARGUMENT='.urlencode($this->get_defined_token($p, '__EVENTARGUMENT')).
                                                                                '&__EVENTVALIDATION='.urlencode($this->get_defined_token($p, '__EVENTVALIDATION')).
                                                                                '&ctl00$cphRoblox$GroupStatusPane$StatusTextBox='.urlencode($content).
                                                                                '&ctl00$cphRoblox$GroupStatusPane$StatusSubmitButton='.urlencode('Group Shout')
                                                                                );     
    }
	
	public function SecurePost($var)
    {
        return mysql_real_escape_string(strip_tags(stripslashes($var)));
    }
    
}
?>