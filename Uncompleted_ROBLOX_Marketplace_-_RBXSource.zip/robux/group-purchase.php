<?php
	include_once 'Header.php';
	$Shop = $RBXAPI->SecurePost($_GET['Shop']);
	if (mysql_num_rows(mysql_query("SELECT * FROM Shops WHERE ID='".$Shop."'")) == 0) {
		echo '<meta http-equiv="refresh" content="0; url=index.php" />';
	}
	$gS = mysql_fetch_object($getShop = mysql_query("SELECT * FROM Shops WHERE ID='".$Shop."'"));
	
	$robux = $RBXAPI->GetGroupFunds($gS->GroupId);
	$RobuxLimit = 20000;
?>
<head>
    <title>Robux Exchange</title>
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="/css/materialize.min.css" media="screen,projection">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" rel="stylesheet" href="/css/temp.css">
    <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
	<script type="text/javascript" src="/js/materialize.min.js"></script>
</head>
<body class="body">
  <div class="w-container container">
    <div class="main card white col s12">
    	<div class="card-content">
        	<?php if($robux<=0){echo 'There are currently no funds inside the group! Check back later.'; exit;}?>
            <span>ROBUX Remaining: <span class="green-text" id="instock">R$<?php echo $robux; ?></span></span>
            <div class="row">
                <form class="col s12 l6" method="POST">
                   	 <h5>Buy ROBUX (instant transfer)</h5>
                   	 <input name="username" type="text" placeholder="ROBLOX Username">
                   	 <input name="robux" min="1" type="number" placeholder="ROBUX Amount">
                     <button type="submit" name="BuySubmit" class="btn-flat green white-text waves-effect">Buy for $<span class="total">0</span> USD</button>
					 <script>$("input[name=\"robux\"]").keyup(function(){$(".total").html(Math.ceil(($(this).val()*2)/1210 + ($(this).val()*2)/1000*0.029 + .3))});</script>
                     <span class="small">You can only buy up to <span class="green-text">R$20,000</span> each day.</span>
                     <span class="small">The ROBUX amount is the EXACT AMOUNT of ROBUX you will receive.</span>
                </form>
            </div>
            <?php
				$Username = $RBXAPI->SecurePost($_POST['username']);
				$Robux = $RBXAPI->SecurePost($_POST['robux']);
				$USD = ceil(($Robux*2)/1210 + ($Robux*2)/1000*0.029 + .3);
				$DateJoined = date("M j, Y");
				$GetRobux;
				if ($GetRobux = substr($robux, 2, 4) == "K+"){
					$GetRobux = substr($robux, 0, 2)."000";
				} else {
					$GetRobux = $robux;
				}

      
				if (isset($_POST['BuySubmit'])) {
					$TodayDate = date('y-m-d');
					$finduser = mysql_query("SELECT * FROM Transactions WHERE Username='".$Username."' AND Payed='Y' AND Date='".$TodayDate."'");
					if ($Robux>$GetRobux){
						echo "There aren't that much funds in the group!";
						echo '<meta http-equiv="refresh" content="2; url=group-purchase.php?Shop='.$Shop.'" />';
						exit;
					} elseif ($RBXAPI->RealUser($Username)) {
						echo "That user was not found!";
						echo '<meta http-equiv="refresh" content="2; url=group-purchase.php?Shop='.$Shop.'" />';
						exit;
					} else {
						$count = $Robux;
						while($fu=mysql_fetch_object($finduser)) {
							$count = $count + $fu->Amount;
						}
						if ($count > $RobuxLimit) {
							echo "Either you are going over the limit, about to hit the limit, or you have already hit your limit of robux.";
							echo '<meta http-equiv="refresh" content="2; url=group-purchase.php?Shop='.$Shop.'" />';
							exit;
						}
						
						function randString($charset='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'){
							$length = 6;
    						$str = '';
    						$count = strlen($charset);
   							while ($length--) {
        						$str .= $charset[mt_rand(0, $count-1)];
    						}
	
	    					return 'RBX-'.$str;
						}
						$GenerateID = randString();
						mysql_query("INSERT INTO Transactions (TransactionID, USD, Username, Shop, Amount,Date)
							 	VALUES ('$GenerateID','$USD','$Username','$gS->GroupId','$Robux','$TodayDate')");
						
				
						echo '<meta http-equiv="refresh" content="0; url=PayPalRedirect.php?id='.$GenerateID.'" />';
					}
				}
			?>
        </div>
     </div>
  </div>
  <div class="hiddendiv common"></div>
</body>