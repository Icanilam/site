<?php
	include_once 'Header.php';
	
	$ID = $RBXAPI->SecurePost($_GET['id']);
	$gP = mysql_fetch_object($getPackage = mysql_query("SELECT * FROM LimitedTransactions WHERE TransactionID='".$ID."'"));
	

	  $business = $CF->PayPal;
	$amount = $gP->USD;
	$return = 'http://'.$_SERVER['SERVER_NAME'].'/Processed2.php?action=success&Trans='.$gP->TransactionID;
	$notifyurl = 'http://'.$_SERVER['SERVER_NAME'].'/Processed2.php?action=ipn';
	$cancelreturn = 'http://'.$_SERVER['SERVER_NAME'].'/Processed2.php?action=cancel&Trans='.$gP->TransactionID;
	$note = 'This was a payment that was done through the website www.robux.exchange and the IPN that this was processed through is www.robux.exchange/Processed2.php so this user has automatically recieved the online currency and cannot be refunded.';
	
  	$paypalurl = "https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&amount=".
  	urlencode($amount)."&memo=".
	urlencode($note)."&business=".
	urlencode($business)."&item_name=".
	urlencode($gP->Item)."&item_number=".urlencode($gP->TransactionID)."&return=".
	urlencode($return)."&rm=2&notify_url=".
	urlencode($notifyurl)."&cancel_return=".
	urlencode($cancelreturn)."&no_note=1&currency_code=USD&custom=".
	urlencode($gP->Buyer);
    
	if ($gP->Payed == "Y"){
   		echo '
			<body class="body">
  				<div class="w-container container">
    				<div class="main card white col s12">
    					<div class="card-content">
            				This was already paid for and claimed.
        				</div>
    				</div>
  				</div>
			</body>
		';
	} else { 
		header( 'Location: '.$paypalurl);
	}
?>