<?php
	include_once '../Header.php';
	
	$getItems = mysql_query("SELECT * FROM Limiteds ORDER BY Cost DESC");
?>
<head>
    <title>Robux Exchange</title>
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="/css/materialize.min.css" media="screen,projection">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" rel="stylesheet" href="/css/temp.css">
    <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
	<script type="text/javascript" src="/js/materialize.min.js"></script>
</head>
<body class="body">
	<div class="w-container container">
    	<div class="main card white col s12">
    		<div class="card-content">
        	    <div class="row">
                	<h5 class="bold" style="margin-bottom:0;">Limiteds</h5>
                    <br>
        	    	<?php
						echo ' <div class="items"> ';
						while($gI = mysql_fetch_object($getItems)) {
							if ($gI->Status == "Available") {
							$LimitedInformation;
							$GetSeller = json_decode(file_get_contents('http://www.robux.exchange/GetLimiteds.php?userId='.$gI->SellerID));
							foreach($GetSeller as $key => $value){if ($key == "Limiteds"){foreach($value as $data => $val) {
								$MatchID = preg_match('/\?id=(\d+)$/', $val->ItemLink, $matches) ? $matches[1] : '';
								if ($MatchID == $gI->ItemID) {
									$LimitedInformation = $val;
								}
							}}}
							echo '
								<div class="item">
									<img class="item-image" src="http://www.roblox.com/Game/Tools/ThumbnailAsset.ashx?aid='.$gI->ItemID.'&amp;fmt=png&amp;wd=420&amp;ht=420">
									<div class="item-content">
										<a target="_blank" href="http://www.roblox.com/Item.aspx?id='.$gI->ItemID.'" class="item-title truncate">'.$LimitedInformation->Name.'</a>
										<span class="item-rap rap">RAP: R$'.number_format($LimitedInformation->AveragePrice).'</span>
										<a href="limited.php?Item='.$gI->ID.'" class="btn btn-small waves-effect waves-light item-purchase green">Buy for '.$gI->Cost.'$</a>
									</div>
								</div>
							';
							}
						}
						echo ' </div> ';
					?>
        		</div>
     		</div>
  		</div>
  		<div class="hiddendiv common"></div>
	</div>
</body>