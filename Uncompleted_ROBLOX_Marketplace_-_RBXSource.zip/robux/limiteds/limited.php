<?php
	include_once '../Header.php';
	$Item = $RBXAPI->SecurePost($_GET['Item']);
	if (mysql_num_rows(mysql_query("SELECT * FROM Limiteds WHERE ID='".$Item."'")) == 0) {
		echo '<meta http-equiv="refresh" content="0; url=index.php" />';
	}
	$gS = mysql_fetch_object($getShop = mysql_query("SELECT * FROM Limiteds WHERE ID='".$Item."'"));
	
	$LimitedInformation;
	$GetSeller = json_decode(file_get_contents('http://www.robux.exchange/GetLimiteds.php?userId='.$gS->SellerID));
	foreach ($GetSeller as $key => $value) {if ($key == "Limiteds") {foreach($value as $data => $val) {
		$MatchID = preg_match('/\?id=(\d+)$/', $val->ItemLink, $matches) ? $matches[1] : '';
		if ($MatchID == $gS->ItemID) {
			$LimitedInformation = $val;
		}
	}}}
	
	if ($LimitedInformation->OriginalPrice == "---") {
		$LimitedInformation->OriginalPrice = '0';
	}
?>
<head>
    <title>Robux Exchange</title>
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="/css/materialize.min.css" media="screen,projection">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" rel="stylesheet" href="/css/temp.css">
    <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
	<script type="text/javascript" src="/js/materialize.min.js"></script>
</head>
<body class="body">
  <div class="w-container container">
    <div class="main card white col s12">
    	<div class="card-content">
        	
            <div class="row">
            	<?php
				if ($gS->Status == "Processing"){echo "Someone is in the process of buying this or is waiting to be confirmed that it was sold."; exit;}elseif($gS->Status == "Taken"){echo "Sorry this item has already been purchased!"; exit;}
				echo '
                	<h4>Purchase Review</h4>
					<h5 class="bold" style="margin-bottom:0;">You are purchasing #'.$LimitedInformation->SerialNumber.' of <a target="_blank" href="'.$LimitedInformation->ItemLink.'">'.$LimitedInformation->Name.'</a> for <span class="rap">$'.$gS->Cost.'</span></h5>
					<span class="small">If you do not purchase right away, the item may be sold while in the process of purchasing.</span>
					<img src="'.$LimitedInformation->ImageLink.'">
					
					<h5>Please enter the ROBLOX account username you want the item be sent to.</h5>
					<ul class="list">
						<li>Please ensure your ROBLOX account has Builders Club (BC).</li>
						<li>Please have a small limited ranging from (<span class="rap">R$50</span> to <span class="rap">R$300</span>).</li>
					</ul>
					<form method="POST">
						<input name="username" placeholder="ROBLOX Username" type="text" autocomplete="off">
						<button name="BuySubmit" class="btn waves-effect waves-light blue darken-3" type="submit">Continue to PayPal</button>			
					</form>
				';
				?>
            <?php
				$Username = $RBXAPI->SecurePost($_POST['username']);
				$USD = $gS->Cost;

      
				if (isset($_POST['BuySubmit'])) {
					$TodayDate = date('y-m-d');
					if ($RBXAPI->RealUser($Username)) {
						echo "That user was not found!";
						echo '<meta http-equiv="refresh" content="2; url=group-purchase.php?Shop='.$Shop.'" />';
						exit;
					} else {
						
						function randString($charset='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'){
							$length = 6;
    						$str = '';
    						$count = strlen($charset);
   							while ($length--) {
        						$str .= $charset[mt_rand(0, $count-1)];
    						}
	
	    					return 'RBX-'.$str;
						}
						$GenerateID = randString();
						$LimitedName = preg_replace("^[\\']^", "", $LimitedInformation->Name);
						mysql_query("INSERT INTO LimitedTransactions (TransactionID, Item, LimitedID, Seller, Buyer, USD, Date)
							 	VALUES ('$GenerateID','$LimitedName','$Item','$gS->SellerID','$Username','$USD','$TodayDate')");
		
				
						echo '<meta http-equiv="refresh" content="0; url=../PayPalRedirect2.php?id='.$GenerateID.'" />';
					}
				}
			?>
        </div>
     </div>
  </div>
  <div class="hiddendiv common"></div>
</body>