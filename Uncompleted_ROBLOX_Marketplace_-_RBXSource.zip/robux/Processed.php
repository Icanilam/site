<?php
include 'Header.php';

define('EMAIL_ADD', $CF->PayPal); // For system notification.
define('PAYPAL_EMAIL_ADD', $CF->PayPal);

// Setup class
require_once('PayPalInc/IPN.php');  // include the class file
$p = new paypal_class( ); 				 // initiate an instance of the class.
$p -> admin_mail = EMAIL_ADD; 
//$p -> paypal_mail = PAYPAL_EMAIL_ADD;  // If set, class will verfy the receiver.
            
switch ($_GET['action']) {
    
   default:      
			$this_script = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
      
      		$p->add_field('business', PAYPAL_EMAIL_ADD); //don't need add this item. if your set the $p -> paypal_mail.
			$p->add_field('return', $this_script.'?action=success');
			$p->add_field('cancel_return', $this_script.'?action=cancel');
			$p->add_field('notify_url', $this_script.'?action=ipn');
			$p->add_field('item_name', 'Paypal Test Transaction');
			$p->add_field('cmd', '_donations');
			$p->add_field('rm', '2');	// Return method = POST
 
      $p->submit_paypal_post(); // submit the fields to paypal
      $p->dump_fields();      // for debugging, output a table of all the fields
      break;
   
   case 'success':      // Order was successful...
   		$TransID = $_GET['Trans'];
   		echo '
			<head>
    			<title>Robux Exchange</title>
    			<link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    			<link type="text/css" rel="stylesheet" href="/css/materialize.min.css" media="screen,projection">
    			<meta name="viewport" content="width=device-width, initial-scale=1.0">
    			<link type="text/css" rel="stylesheet" href="/css/temp.css">
    			<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
				<script type="text/javascript" src="/js/materialize.min.js"></script>
			</head>
			<body class="body">
  				<div class="w-container container">
    				<div class="main card white col s12">
    					<div class="card-content">
            				<p>Purchase Success! You will be redirected to claim your robux in <span id="counter">15</span> second(s).</p>
							<script type="text/javascript">
								function countdown() {
    								var i = document.getElementById("counter");
    								i.innerHTML = parseInt(i.innerHTML)-1;
								}
								setInterval(function(){ countdown(); },1000);
							</script>
        				</div>
    				</div>
  				</div>
			</body>
			<meta http-equiv="refresh" content="15; url=claim.php?Transaction='.$TransID.'" />
		';
	
   break;
      
   case 'cancel':       // Order was canceled...

	  echo '
	  		<head>
    			<title>Robux Exchange</title>
    			<link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    			<link type="text/css" rel="stylesheet" href="/css/materialize.min.css" media="screen,projection">
    			<meta name="viewport" content="width=device-width, initial-scale=1.0">
    			<link type="text/css" rel="stylesheet" href="/css/temp.css">
    			<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
				<script type="text/javascript" src="/js/materialize.min.js"></script>
			</head>
			<body class="body">
  				<div class="w-container container">
    				<div class="main card white col s12">
    					<div class="card-content">
            				Something went wrong. Contact "avatarnation" on skype if this a serious error.
        				</div>
    				</div>
  				</div>
			</body>
		';
			
      
      break;
      
   case 'ipn':          
      
      if ($p->validate_ipn()) {
          
		$item_name = $_POST['item_name'];
		$item_num = $_POST['item_number'];
		$item_price = $_POST['mc_gross'];
		$payment_status = $_POST['payment_status'];
		$payer_email = $_POST['payer_email'];
		$username = $_POST['custom'];
		if ($payment_status == "Completed") {
			$gT = mysql_fetch_object($getTrans = mysql_query("SELECT * FROM Transactions WHERE TransactionID='".$item_num."'"));
			
			if ($item_price == $gT->USD) {
				mysql_query("UPDATE Transactions SET Payed='Y' WHERE TransactionID='$item_num'");
			} else {
				$Login = $RBXAPI->DoLogin();
				if ($RBXAPI->IsLoggedIn() == true) {
					$BuyerID = $RBXAPI->GetUserID($gT->Buyer);
					$RBXAPI->SendPM($BuyerID,'yo dude gtfo','you are not getting this crap for cheaper than the set price, thanks for the donation though :)');
				}
			}
		}
      } else {
			
		 echo '
		 	<head>
    			<title>Robux Exchange</title>
    			<link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    			<link type="text/css" rel="stylesheet" href="/css/materialize.min.css" media="screen,projection">
    			<meta name="viewport" content="width=device-width, initial-scale=1.0">
    			<link type="text/css" rel="stylesheet" href="/css/temp.css">
    			<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
				<script type="text/javascript" src="/js/materialize.min.js"></script>
			</head>
			<body class="body">
  				<div class="w-container container">
    				<div class="main card white col s12">
    					<div class="card-content">
            				Something went wrong. Contact "avatarnation" on skype if this a serious error.
        				</div>
    				</div>
  				</div>
			</body>
		';
			
     }
   break;
}
?>