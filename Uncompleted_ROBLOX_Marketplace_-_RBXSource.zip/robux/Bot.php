<?php
include_once 'API.php';

$RBLXClass = new MyRBLXClass();
$Login = $RBLXClass->DoLogin();


//echo $RBLXClass->GiveGroupFunds(260996,23370881,16);
echo $RBLXClass->SendTrade(53866328,1029025);

?>