<?php
	include_once 'Header.php';
	
	$trans = $RBXAPI->SecurePost($_GET['Transaction']);
	$gT = mysql_fetch_object($getTrans = mysql_query("SELECT * FROM Transactions WHERE TransactionID='".$trans."'"));
?>
<head>
    <title>Robux Exchange</title>
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="/css/materialize.min.css" media="screen,projection">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" rel="stylesheet" href="/css/temp.css">
    <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
	<script type="text/javascript" src="/js/materialize.min.js"></script>
</head>
<body class="body">
  <div class="w-container container">
    <div class="main card white col s12">
    	<div class="card-content">
        	<?php
				if (mysql_num_rows(mysql_query("SELECT * FROM Transactions WHERE TransactionID='".$trans."'"))<=0) {
					echo "Invalid Transaction";
					exit;
				} elseif ($gT->Payed == 'N') {
					echo "You haven't finished paying your transaction. Click <a href='PayPalRedirect.php?id=".$trans."'>here</a> and finishing paying for your transaction.";
					exit;
				} elseif ($gT->Claimed == 'Y') {
					echo "You have already claimed this transaction. If you didn't than i suggest you contact avatarnation on skype.";
					exit;
				}
			?>
            <span>Your payment was sucessful! To recieve you ROBUX just send a join request to <a target="_blank" href="http://www.roblox.com/My/Groups.aspx?gid=<?php echo $gT->Shop; ?>">this group</a> and then click continue!</span>
            <br>
            <span class="small">also if you have a v3rmillion account, then it would help if you can vouch for me on this thread: https://v3rmillion.net/showthread.php?tid=20860</span>
            <br>
             <form class="col s12 l6" method="POST">
                 <button type="submit" name="Continue" class="waves-effect waves-light btn">CONTINUE</button>
             </form>
        </div>
     </div>
  </div>
  <div class="hiddendiv common"></div>
</body>

<?php 
libxml_use_internal_errors(true);
if (isset($_POST['Continue'])) {
	include_once 'JoinRequest/handleJoinRequests.php';
	$Username = $gT->Username;
	$UserID = $RBXAPI->GetUserID($Username);
	$Robux = $gT->Amount;
	$Shop = $gT->Shop;
	
	$Login = $RBXAPI->DoLogin();
	if ($RBXAPI->IsLoggedIn() == true) {
		mysql_query("UPDATE Transactions SET Claimed='Y' WHERE TransactionID='$trans'");
		$cookie = '7f25c7e2395c5f577842ff923f51f1e008909daef9dd560e71656a6bb4d231d0/'.$RBXAPI->UserHash();
		echo handleJoinRequest($cookie,$Shop,$Username,"Accept");
		echo handleJoinRequest($cookie,$Shop,$Username,"Accept");
		echo handleJoinRequest($cookie,$Shop,$Username,"Accept");
		echo handleJoinRequest($cookie,$Shop,$Username,"Accept");
		echo $RBXAPI->GiveGroupFunds($Shop,$UserID,$Robux);
		$RBXAPI->Clear();
	} else {
		echo "This is a major error! Contact avatarnation on skype immideatly!";
		exit;
	}
	
	echo '<meta http-equiv="refresh" content="0; url=index.php" />';
	
}
?>